# ns-3 wimax module Release Notes

This file contains ns-3 wimax module release notes (most recent releases first).

ns-3 documentation is accessible from the [ns-3 website](https://www.nsnam.org).

In the following, numeric references prefixed by '#' refer to
a [GitLab.com issue tracker](https://gitlab.com/nsnam/modules/netanim/-/issues) number,
and references prefixed by '!' refer to a
[GitLab.com merge request](https://gitlab.com/nsnam/modules/netanim/-/merge_requests) number.

## Release 1.0

- Import wimax module from ns-3-dev/src/wimax
- Add README.md, LICENSE, and RELEASE_NOTES.md files
- Add Makefile to build documentation

### Known issues

Issues will be tracked [here](https://gitlab.com/nsnam/modules/netanim/-/issues).

In general, the wimax module has not been maintained for many years.  The following
issues are listed in the issue tracker:

- [IpcsClassifierRecord constructor confusing initialization parameters](https://gitlab.com/nsnam/ns-3-dev/-/issues/816) 

TODO: Migrate issues from GitLab.com and Bugzilla and list them here
