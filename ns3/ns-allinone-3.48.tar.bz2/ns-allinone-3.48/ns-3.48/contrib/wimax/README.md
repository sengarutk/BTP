# WiMAX module for ns-3

This extension module for ns-3 adds a WiMAX (IEEE 802.16) NetDevice model.  This module was part
of the main ns-3 distribution until release ns-3.46, at which time it was moved to the
[ns-3 App Store](https://apps.nsnam.org) as an extension module.

## License

This software is licensed under the terms of the GNU General Public License v2.0 only
(GPL-2.0-only).  See the LICENSE file for more details.

## Installation

Download or clone this module into the `contrib` directory of ns-3.   

This module cannot be installed into the `contrib` directory for releases older than ns-3.46,
because it instead already resides in the `src` directory for older releases.

Check the release notes to learn which versions of this module are compatible with which ns-3
releases.
