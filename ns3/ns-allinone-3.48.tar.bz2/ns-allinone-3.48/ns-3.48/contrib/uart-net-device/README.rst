UART NetDevice module
=====================

This is the `ns-3 <https://www.nsnam.org>`_ uart-net-device module
used to add co-processor capabilities to the ns-3 network simulator. The present
module can be added to ns-3 in a plug-in fashion. For details about this module look at the documentation in the doc/ folder.

License
-------

This software is licensed under the terms of the GNU GPLv2, as those used by ns-3.
See the LICENSE file for more details.

Copyright (c) 2025-2026 Tokushima University, Japan.
SPDX-License-Identifier: GPL-2.0-only

Papers
------

The following is a list of papers published in relation to this module:

- [`1 <https://dl.acm.org/doi/10.1145/3747204.3747209>`_] Alberto Gallegos Ramonet, Tommaso Pecorella, and Kazuhiko Kinoshita. 2025. Network Co-Processor Solutions for IoT Designs on ns-3. In Proceedings of the 2025 International Conference on ns-3 (ICNS3 '25). Association for Computing Machinery, New York, NY, USA, 97–106. https://doi.org/10.1145/3747204.3747209.
- [`2 <https://www.sciencedirect.com/science/article/pii/S1389128624005814>`_] Alberto Gallegos Ramonet, Tommaso Pecorella, Benedetta Picano, Kazuhiko Kinoshita, Perspectives on IoT-oriented network simulation systems, Computer Networks, Volume 253, 2024, 110749,ISSN 1389-1286, https://doi.org/10.1016/j.comnet.2024.110749.

Author
------

Alberto Gallegos Ramonet


Versions
--------

The following is table with the supported versions of ns-3
for each uart-net-device release, other versions might work but they
are untested:

.. table::
   :align: center
   :widths: auto

   +--------------------------+------------------+---------------+--------------------+----------------------+
   | uart-net-device version  | ns-3 version     | Build system  | CommonShim version |  Release date        |
   +==========================+==================+===============+====================+======================+
   | v1.2.2                   | ns-3.48          | cmake         | v1.1               | July 6th, 2026     |
   +--------------------------+------------------+---------------+--------------------+----------------------+
   | v1.2                     | ns-3.47          | cmake         | v1.1               | February 18th, 2026  |
   +--------------------------+------------------+---------------+--------------------+----------------------+
   | v1.1                     | ns-3.46          | cmake         | v1.0               | December 3rd, 2025   |
   +--------------------------+------------------+---------------+--------------------+----------------------+
   | v1.0                     | ns-3.45          | cmake         | v1.0               | June 2nd, 2025       |
   +--------------------------+------------------+---------------+--------------------+----------------------+
   | v1.0                     | ns-3.44          | cmake         | v1.0               | June 2nd, 2025       |
   +--------------------------+------------------+---------------+--------------------+----------------------+

Prerequisites
-------------

This model requires ns-3.44 or later to work and requires the external library libboost 1.74 or later to work. This is because ``boost:asio`` library is used to perform the serial communications used by this model.

You can install the Boost library in a variety of ways, for instance using the ``apt-get`` command::

    sudo apt-get install libboost1.74-dev

The present model has been designed to work on top of real NXP JN5169 device containing our original `CommonShimLayer`. For instructions of how to prepare JN5169 devices with the CommonShimLayer follow the instructions in the CommonShimLayer repo:

https://gitlab.com/shattered.feelings/jn51xx.git

**Note**: It is not necessary to compile the CommonShimLayer on your own, you can simply use the precompiled ``CommonShim_JN5169.bin`` file and flash it into your JN5169 device by using one the available flash programmers.

Installation
------------

Download ns-3 and navigate to the contrib folder, then download the uart-net-device module
and switch to the desired uart-net-device version. For example to use the latest version::

    cd contrib
    git clone https://gitlab.com/shattered.feelings/uart-net-device.git
    cd uart-net-device
    git checkout v1.2.2

Usage
-----

Usage instructions and examples can be found in the `doc/` folder of this module.
