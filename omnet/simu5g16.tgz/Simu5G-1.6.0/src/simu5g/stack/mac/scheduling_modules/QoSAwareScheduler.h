//
//                  Simu5G
//
// Authors: Mohamed Seliem (University College Cork)
//
// This file is part of a software released under the license included in file
// "license.pdf". Please read LICENSE and README files before using it.
// The above files and the present reference are part of the software itself,
// and cannot be removed from it.
//


#ifndef STACK_MAC_SCHEDULING_MODULES_QOSAWARESCHEDULER_H_
#define STACK_MAC_SCHEDULING_MODULES_QOSAWARESCHEDULER_H_

#include "simu5g/stack/mac/scheduler/LteScheduler.h"
#include "simu5g/stack/mac/DrbQosEntry.h"
#include <map>
#include <queue>

namespace simu5g {

/**
 * Extends the LTE/NR MAC layer scheduler to support QoS-aware scheduling
 * decisions based on QFI (QoS Flow Identifier) contexts. DrbTable
 * maintains mappings between QFIs, CIDs, and their associated QoS parameters.
 *
 * Key Features:
 * - Implements a PF-based scheduler that dynamically scores active CIDs using
 *   QoS weights derived from QFI context (e.g., 5QI, GBR, delay budget, PER,
 *   priority).
 * - Supports per-CID registration of QFIs
 * - DrbTable can load QFI-DRB configurations from file
 * - Provides flexible QoS weight computation based on service criticality.
 * - Enables more realistic traffic differentiation for scenarios involving
 *   conversational voice, URLLC, video streaming, etc.
 *
 * Notes:
 * - Scheduler gracefully defaults to best-effort when no QFI context is found.
 */
class QoSAwareScheduler : public LteScheduler
{
  protected:
    typedef std::map<MacCid, double> PfRate;
    typedef std::pair<MacCid, double> ScoredCid;

    PfRate pfRate_;
    std::map<MacCid, unsigned int> grantedBytes_;
    double pfAlpha_;
    const double scoreEpsilon_ = 1e-6;

    const std::map<DrbKey, DrbQosEntry> *drbQosMap_ = nullptr;

    // QoS weight parameters  TODO initialize from NED parameters
    double gbrMultiplier_ = 2.0;
    double priorityBase_ = 10.0;       // weight contribution = priorityBase_ / (priorityLevel + 1)
    double delayUrgentMs_ = 10.0;      // delay budget thresholds (ms)
    double delayTightMs_ = 50.0;
    double delayLooseMs_ = 100.0;
    double delayUrgentMultiplier_ = 5.0;  // multipliers for each tier
    double delayTightMultiplier_ = 3.0;
    double delayLooseMultiplier_ = 1.5;

    // Helpers
    double computeQosWeight(const DrbQosEntry& e);
    const DrbQosEntry* getDrbQosForCid(MacCid cid);

  public:
    double& pfAlpha() { return pfAlpha_; }

    QoSAwareScheduler(Binder* binder, double pfAlpha);
    void setDrbQosMap(const std::map<DrbKey, DrbQosEntry> *m) { drbQosMap_ = m; }
    void prepareSchedule() override;
    void commitSchedule() override;
};

} // namespace simu5g

#endif /* STACK_MAC_SCHEDULING_MODULES_QOSAWARESCHEDULER_H_ */

