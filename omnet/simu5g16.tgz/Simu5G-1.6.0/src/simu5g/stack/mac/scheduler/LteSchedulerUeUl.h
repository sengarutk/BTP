//
//                  Simu5G
//
// Copyright (C) 2012-2021 Giovanni Nardini, Giovanni Stea, Antonio Virdis et al. (University of Pisa)
// Copyright (C) 2022-2026 Giovanni Nardini, Giovanni Stea et al. (University of Pisa)
//
// This file is part of a software released under the license included in file
// "license.pdf". Please read LICENSE and README files before using it.
// The above files and the present reference are part of the software itself,
// and cannot be removed from it.
//

#ifndef _LTE_LTE_SCHEDULER_UE_UL_H_
#define _LTE_LTE_SCHEDULER_UE_UL_H_

#include "simu5g/common/LteCommon.h"

#include "simu5g/stack/mac/LteMacUe.h"
#include "simu5g/stack/mac/scheduler/LcgScheduler.h"

namespace simu5g {

using namespace omnetpp;

class LteMacUe;
class LcgScheduler;

/**
 * LTE Ue uplink scheduler.
 */
class LteSchedulerUeUl
{
  protected:

    // MAC module, queried for parameters
    opp_component_ptr<LteMacUe> mac_;

    // Schedule List
    LteMacScheduleList scheduleList_;

    // Scheduled Bytes List
    LteMacScheduleList scheduledBytesList_;

    // Inner Scheduler - defaults to Standard LCG
    LcgScheduler lcgScheduler_;

    // Carrier frequency handled by this scheduler
    GHz carrierFrequency_;

  public:

    /* Performs the standard LCG scheduling algorithm
     * @returns reference to scheduling list
     */
    LteMacScheduleList *schedule();

    /* After the scheduling, returns the amount of bytes
     * scheduled for each connection
     */
    LteMacScheduleList *getScheduledBytesList();

    /* After scheduling, returns the per-PDU payload sizes planned for an NR-SO
     * connection (one SDU request per entry), or nullptr for LTE-FI connections.
     */
    const std::vector<unsigned int> *getScheduledSoPduSizes(MacCid cid) { return lcgScheduler_.getScheduledSoPduSizes(cid); }

    /*
     * Constructor
     */
    LteSchedulerUeUl(LteMacUe *mac, GHz carrierFrequency);

    /**
     * Copy constructor and operator=
     */
    LteSchedulerUeUl(const LteSchedulerUeUl& other) :
        mac_(other.mac_),
        scheduleList_(other.scheduleList_),
        scheduledBytesList_(other.scheduledBytesList_),
        lcgScheduler_(other.lcgScheduler_),
        carrierFrequency_(other.carrierFrequency_)
    {
    }

    LteSchedulerUeUl& operator=(const LteSchedulerUeUl& other);

    /*
     * Destructor
     */
    ~LteSchedulerUeUl();
};

} //namespace

#endif // _LTE_LTE_SCHEDULER_UE_UL_H_

