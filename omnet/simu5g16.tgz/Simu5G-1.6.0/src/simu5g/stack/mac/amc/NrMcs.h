//
//                  Simu5G
//
// Copyright (C) 2019-2021 Giovanni Nardini, Giovanni Stea, Antonio Virdis et al. (University of Pisa)
// Copyright (C) 2022-2026 Giovanni Nardini, Giovanni Stea et al. (University of Pisa)
//
// This file is part of a software released under the license included in file
// "license.pdf". Please read LICENSE and README files before using it.
// The above files and the present reference are part of the software itself,
// and cannot be removed from it.
//

#ifndef _NRMCS_H_
#define _NRMCS_H_

#include "simu5g/common/LteCommon.h"
#include "simu5g/stack/mac/amc/LteMcs.h"

namespace simu5g {

// This file contains MCS types and constants; MCS and ITBS tables;
// and functions related to MCS and Tx-Modes.

struct NrMcsElem
{
    LteMod mod_;       /// modulation (Qm)
    double coderate_;  /// code rate (R)

    NrMcsElem(LteMod mod = _QPSK, double coderate = 0.0) : mod_(mod), coderate_(coderate)
    {
    }

};

/**
 * <MCS Index> , <Modulation> , <code rate>
 * This table contains values taken from tables 5.1.3.1-1 and 5.1.3.1-2 (TS 38.214)
 */
class NrMcsTable
{
    bool extended_;

  public:

    /**
     * <CQI Index [0-15]> , <Modulation> , <Code Rate x 1024>
     * This table contains values taken from table 7.2.3-1 (TS 38.214)
     */
    CqiElem cqiTable[MAXCQI + 1];

    NrMcsElem table[CQI2ITBSSIZE];

    NrMcsTable(bool extended = true);

    CqiElem getCqiElem(int i)
    {
        return cqiTable[i];
    }

    unsigned int getMinIndex(LteMod mod);
    unsigned int getMaxIndex(LteMod mod);

    /// MCS table seek operator
    NrMcsElem& at(Tbs tbs)
    {
        return table[tbs];
    }

};

const unsigned int TBSTABLESIZE = 94;
extern const unsigned int nInfoToTbs[TBSTABLESIZE];

} //namespace

#endif

