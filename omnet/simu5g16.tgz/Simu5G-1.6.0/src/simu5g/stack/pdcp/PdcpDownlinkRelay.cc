//
//                  Simu5G
//
// Authors: Giovanni Nardini, Giovanni Stea, Antonio Virdis (University of Pisa)
//
// This file is part of a software released under the license included in file
// "license.pdf". Please read LICENSE and README files before using it.
// The above files and the present reference are part of the software itself,
// and cannot be removed from it.
//

#include "simu5g/stack/pdcp/PdcpDownlinkRelay.h"
#include "simu5g/common/LteControlInfoTags_m.h"

namespace simu5g {

Define_Module(PdcpDownlinkRelay);

simsignal_t PdcpDownlinkRelay::sentPacketToLowerLayerSignal_ = registerSignal("sentPacketToLowerLayer");
simsignal_t PdcpDownlinkRelay::pdcpSduSentSignal_ = registerSignal("pdcpSduSent");

void PdcpDownlinkRelay::initialize(int stage)
{
    (void)stage; // nothing to initialize
}

void PdcpDownlinkRelay::handlePacketFromUpperLayer(inet::Packet *pkt)
{
    // DC bypass: packet is already a PDCP PDU from the master node.
    // Forward directly to RLC without any PDCP processing.
    EV << NOW << " PdcpDownlinkRelay::handlePacketFromUpperLayer - forwarding packet " << pkt->getName() << " to RLC (DC bypass)" << endl;

    auto lteInfo = pkt->getTag<FlowControlInfo>();
    if (hasListeners(pdcpSduSentSignal_) && lteInfo->getDirection() != D2D_MULTI && lteInfo->getDirection() != D2D) {
        emit(pdcpSduSentSignal_, pkt);
    }
    emit(sentPacketToLowerLayerSignal_, pkt);

    send(pkt, "out");
}

} // namespace simu5g
