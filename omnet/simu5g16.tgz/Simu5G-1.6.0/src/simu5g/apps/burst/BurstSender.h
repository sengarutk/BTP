//
//                  Simu5G
//
// Copyright (C) 2012-2021 Giovanni Nardini, Giovanni Stea, Antonio Virdis et al. (University of Pisa)
// Copyright (C) 2022-2026 Giovanni Nardini, Giovanni Stea et al. (University of Pisa)
//
// This file is part of a software released under the license included in file
// "license.pdf". Please read LICENSE and README files before using it.
// The above files and the present reference are part of the software itself,
// and cannot be removed from it.
//
#ifndef _BURSTSENDER_H_
#define _BURSTSENDER_H_

#include <string.h>

#include <inet/common/INETDefs.h>
#include <inet/transportlayer/contract/udp/UdpSocket.h>
#include <inet/networklayer/common/L3AddressResolver.h>

#include "simu5g/common/LteDefs.h"
#include "BurstPacket_m.h"

namespace simu5g {

using namespace inet;

class BurstSender : public cSimpleModule, public inet::UdpSocket::ICallback
{
    UdpSocket socket;

    // timers
    cMessage *burstTimer_ = nullptr;
    cMessage *packetTimer_ = nullptr;

    // sender
    int burstId_ = 0;
    int frameId_ = 0;

    int burstSize_;
    int packetSize_;
    simtime_t startTime_;
    simtime_t interBurstTime_;
    simtime_t intraBurstTime_;

    static simsignal_t burstSentPktSignal_;
    // ----------------------------

    cMessage *initTraffic_ = nullptr;

    simtime_t timestamp_;
    int localPort_;
    int destPort_;
    L3Address destAddress_;

    void initTraffic();
    void sendBurst();
    void sendPacket();

  public:
    ~BurstSender() override;

  protected:

    int numInitStages() const override { return inet::NUM_INIT_STAGES; }
    void initialize(int stage) override;
    void handleMessage(cMessage *msg) override;

    // UdpSocket::ICallback methods
    void socketDataArrived(inet::UdpSocket *socket, inet::Packet *packet) override;
    void socketErrorArrived(inet::UdpSocket *socket, inet::Indication *indication) override;
    void socketClosed(inet::UdpSocket *socket) override;
};

} //namespace

#endif

