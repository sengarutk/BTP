//
//                  Simu5G
//
// Copyright (C) 2012-2021 Giovanni Nardini, Giovanni Stea, Antonio Virdis et al. (University of Pisa)
// Copyright (C) 2022-2026 Giovanni Nardini, Giovanni Stea et al. (University of Pisa)
//
// This file is part of a software released under the license included in file
// "license.pdf". Please read LICENSE and README files before using it.
// The above files and the present reference are part of the software itself,
// and cannot be removed from it.
//
//

#ifndef _LTE_VODUDPCLIENT_H_
#define _LTE_VODUDPCLIENT_H_

#include <string.h>
#include <fstream>

#include "simu5g/common/LteDefs.h"
#include "simu5g/apps/vod/VoDPacket_m.h"
#include "simu5g/apps/vod/VoDUDPStruct.h"
#include <inet/transportlayer/contract/udp/UdpSocket.h>
#include <inet/networklayer/common/L3AddressResolver.h>

namespace simu5g {

using namespace omnetpp;

class VodUdpClient : public cSimpleModule, public inet::UdpSocket::ICallback
{
    inet::UdpSocket socket;
    std::fstream outfile;
    unsigned int totalRcvdBytes_ = 0;

  public:
    static simsignal_t tptLayer0Signal_;
    static simsignal_t tptLayer1Signal_;
    static simsignal_t tptLayer2Signal_;
    static simsignal_t tptLayer3Signal_;
    static simsignal_t delayLayer0Signal_;
    static simsignal_t delayLayer1Signal_;
    static simsignal_t delayLayer2Signal_;
    static simsignal_t delayLayer3Signal_;

  protected:

    void initialize(int stage) override;
    int numInitStages() const override { return inet::NUM_INIT_STAGES; }
    void finish() override;
    void handleMessage(cMessage *msg) override;
    virtual void receiveStream(const VoDPacket *msg);

    // UdpSocket::ICallback methods
    void socketDataArrived(inet::UdpSocket *socket, inet::Packet *packet) override;
    void socketErrorArrived(inet::UdpSocket *socket, inet::Indication *indication) override;
    void socketClosed(inet::UdpSocket *socket) override;
};

} //namespace

#endif

