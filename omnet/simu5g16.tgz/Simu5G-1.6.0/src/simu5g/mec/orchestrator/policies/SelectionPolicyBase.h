//
//                  Simu5G
//
// Copyright (C) 2019-2021 Giovanni Nardini, Giovanni Stea, Antonio Virdis et al. (University of Pisa)
// Copyright (C) 2022-2026 Giovanni Nardini, Giovanni Stea et al. (University of Pisa)
//
// This file is part of a software released under the license included in file
// "license.pdf". Please read LICENSE and README files before using it.
// The above files and the present reference are part of the software itself,
// and cannot be removed from it.
//

#ifndef NODES_MEC_MECORCHESTRATOR_SELECTIONPOLICYBASE_H_
#define NODES_MEC_MECORCHESTRATOR_SELECTIONPOLICYBASE_H_

#include "simu5g/mec/orchestrator/MecOrchestrator.h"
#include "simu5g/mec/orchestrator/ApplicationDescriptor.h"

namespace simu5g {

class MecOrchestrator;

class SelectionPolicyBase
{
    friend class MecOrchestrator;

  protected:
    MecOrchestrator *mecOrchestrator_ = nullptr;
    virtual cModule *findBestMecHost(const ApplicationDescriptor&) = 0;

  public:
    SelectionPolicyBase(MecOrchestrator *mecOrchestrator) : mecOrchestrator_(mecOrchestrator) {}
};

} //namespace

#endif /* NODES_MEC_MECORCHESTRATOR_SELECTIONPOLICYBASE_H_ */

