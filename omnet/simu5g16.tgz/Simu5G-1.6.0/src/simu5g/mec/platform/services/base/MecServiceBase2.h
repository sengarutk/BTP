//
//                  Simu5G
//
// Copyright (C) 2019-2021 Giovanni Nardini, Giovanni Stea, Antonio Virdis et al. (University of Pisa)
// Copyright (C) 2022-2026 Giovanni Nardini, Giovanni Stea et al. (University of Pisa)
//
// This file is part of a software released under the license included in file
// "license.pdf". Please read LICENSE and README files before using it.
// The above files and the present reference are part of the software itself,
// and cannot be removed from it.
//

#ifndef __SIMU5G_MECSERVICEBASE2_H
#define __SIMU5G_MECSERVICEBASE2_H

#include "simu5g/mec/platform/services/base/MecServiceBase.h"

namespace simu5g {

class MecServiceBase2 : public MecServiceBase
{
  protected:
    void initialize(int stage) override;
};

} //namespace

#endif // __SIMU5G_MECSERVICEBASE2_H

