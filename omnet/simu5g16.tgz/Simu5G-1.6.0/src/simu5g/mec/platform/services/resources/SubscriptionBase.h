//
//                  Simu5G
//
// Copyright (C) 2019-2021 Giovanni Nardini, Giovanni Stea, Antonio Virdis et al. (University of Pisa)
// Copyright (C) 2022-2026 Giovanni Nardini, Giovanni Stea et al. (University of Pisa)
//
// This file is part of a software released under the license included in file
// "license.pdf". Please read LICENSE and README files before using it.
// The above files and the present reference are part of the software itself,
// and cannot be removed from it.
//

#ifndef APPS_MEC_MESERVICES_RESOURCES_SUBSCRIPTIONBASE_H_
#define APPS_MEC_MESERVICES_RESOURCES_SUBSCRIPTIONBASE_H_

#include <inet/transportlayer/contract/tcp/TcpSocket.h>

#include "simu5g/common/utils/utils.h"
#include "simu5g/mec/platform/EventNotification/EventNotification.h"
#include "simu5g/mec/platform/services/messages/AperiodicSubscriptionTimer_m.h"
#include "simu5g/mec/platform/services/resources/AttributeBase.h"
#include "simu5g/mec/platform/services/resources/TimeStamp.h"
#include "simu5g/mec/utils/httpUtils/httpUtils.h"

namespace simu5g {

using namespace omnetpp;

class SubscriptionBase
{
  public:
    SubscriptionBase();
    SubscriptionBase(unsigned int subId, inet::TcpSocket *socket, const std::string& baseResLocation, std::set<cModule *, simu5g::utils::cModule_LessId>& eNodeBs);
    virtual ~SubscriptionBase();

    void addEnodeB(std::set<cModule *, simu5g::utils::cModule_LessId>& eNodeBs);
    void addEnodeB(cModule *eNodeB);

    virtual void set_links(const std::string& link);

    virtual bool fromJson(const nlohmann::ordered_json& json);
    virtual void sendSubscriptionResponse() = 0;
    virtual void sendNotification(EventNotification *event) = 0;
    virtual EventNotification *handleSubscription() = 0;

    virtual std::string getSubscriptionType() const;
    virtual int getSubscriptionId() const;
    virtual int getSocketConnId() const;
  protected:

    inet::TcpSocket *socket_ = nullptr;
    TimeStamp timestamp_;

    std::string baseResLocation_;

    std::string clientHost_;
    std::string clientUri_;

    std::map<MacCellId, CellInfo *> eNodeBs_;
    unsigned int subscriptionId_;

    std::string subscriptionType_;
    std::string notificationType_;
    std::string links_;

    std::string callbackReference_;
    TimeStamp expiryTime_;
};

} //namespace

#endif /* APPS_MEC_MESERVICES_RESOURCES_SUBSCRIPTIONBASE_H_ */

