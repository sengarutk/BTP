//
//                  Simu5G
//
// Copyright (C) 2019-2021 Giovanni Nardini, Giovanni Stea, Antonio Virdis et al. (University of Pisa)
// Copyright (C) 2022-2026 Giovanni Nardini, Giovanni Stea et al. (University of Pisa)
//
// This file is part of a software released under the license included in file
// "license.pdf". Please read LICENSE and README files before using it.
// The above files and the present reference are part of the software itself,
// and cannot be removed from it.
//

#ifndef APPS_MEC_MESERVICES_LOCATIONSERVICE_RESOURCES_CURRENTLOCATION_H_
#define APPS_MEC_MESERVICES_LOCATIONSERVICE_RESOURCES_CURRENTLOCATION_H_

#include "simu5g/mec/platform/services/resources/AttributeBase.h"
#include "simu5g/mec/platform/services/resources/TimeStamp.h"

namespace simu5g {

class CurrentLocation : public AttributeBase
{
  protected:
    double accuracy;
    inet::Coord coords;
    TimeStamp timeStamp;

  public:
    CurrentLocation();
    CurrentLocation(double accuracy, const inet::Coord& coords, const TimeStamp& ts);
    CurrentLocation(double accuracy, const inet::Coord& coords);

    nlohmann::ordered_json toJson() const override;
};

} //namespace

#endif /* APPS_MEC_MESERVICES_LOCATIONSERVICE_RESOURCES_CURRENTLOCATION_H_ */

