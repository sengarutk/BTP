//
//                  Simu5G
//
// Copyright (C) 2019-2021 Giovanni Nardini, Giovanni Stea, Antonio Virdis et al. (University of Pisa)
// Copyright (C) 2022-2026 Giovanni Nardini, Giovanni Stea et al. (University of Pisa)
//
// This file is part of a software released under the license included in file
// "license.pdf". Please read LICENSE and README files before using it.
// The above files and the present reference are part of the software itself,
// and cannot be removed from it.
//

#include "simu5g/mec/platform/services/base/MecServiceBase2.h"

#include "simu5g/mec/mepm/MecPlatformManager.h"

namespace simu5g {

using namespace omnetpp;

void MecServiceBase2::initialize(int stage)
{
    MecServiceBase::initialize(stage);

    if (stage == inet::INITSTAGE_LOCAL) {
        loadGenerator_ = par("loadGenerator").boolValue();
        if (loadGenerator_) {
            beta_ = par("betaa").doubleValue();
            lambda_ = 1 / beta_;
            numBgApps_ = par("numBgApps").intValue();
            /*
             * check if the system is stable.
             * For M/M/1 --> rho (lambda_/mu) < 1
             * If arrivals come from multiple independent exponential sources:
             * (numBgApps * lambda_) / mu < 1
             */
            double lambdaT = lambda_ * (numBgApps_ + 1);
            rho_ = lambdaT * requestServiceTime_;
            if (rho_ >= 1)
                throw cRuntimeError("M/M/1 system is unstable: rho is %f", rho_);
            EV << "MecServiceBase::initialize - rho: " << rho_ << endl;
        }

        int found = getParentModule()->findSubmodule("serviceRegistry");
        if (found == -1)
            throw cRuntimeError("MecServiceBase::initialize - ServiceRegistry not present!");
        servRegistry_ = check_and_cast<ServiceRegistry *>(getParentModule()->getSubmodule("serviceRegistry"));

        cModule *module = meHost_->getSubmodule("mecPlatformManager");
        if (module != nullptr) {
            EV << "MecServiceBase::initialize - MecPlatformManager found" << endl;
            mecPlatformManager_ = check_and_cast<MecPlatformManager *>(module);
        }

        // get the BSs connected to the mec host
        getConnectedBaseStations();
    }
}

} //namespace

