//
//                  Simu5G
//
// Copyright (C) 2019-2021 Giovanni Nardini, Giovanni Stea, Antonio Virdis et al. (University of Pisa)
// Copyright (C) 2022-2026 Giovanni Nardini, Giovanni Stea et al. (University of Pisa)
//
// This file is part of a software released under the license included in file
// "license.pdf". Please read LICENSE and README files before using it.
// The above files and the present reference are part of the software itself,
// and cannot be removed from it.
//

#ifndef _LOCATION_H_
#define _LOCATION_H_

#include <map>
#include <set>

#include <inet/networklayer/contract/ipv4/Ipv4Address.h>

#include "simu5g/common/LteCommon.h"
#include "simu5g/common/binder/Binder.h"
#include "simu5g/common/utils/utils.h"
#include "simu5g/mec/platform/services/LocationService/resources/UserInfo.h"
#include "simu5g/mec/platform/services/resources/TimeStamp.h"

namespace simu5g {

using namespace omnetpp;

class CellInfo;

class LocationResource : public AttributeBase
{
  public:
    /**
     * The constructor takes a vector of the eNodeBs connected to the MeHost
     * and creates a CellInfo object
     */
    LocationResource();
    LocationResource(const std::string& baseUri, std::set<cModule *, simu5g::utils::cModule_LessId>& eNodeBs, Binder *binder);

    nlohmann::ordered_json toJson() const override;

    void addEnodeB(std::set<cModule *, simu5g::utils::cModule_LessId>& eNodeBs);
    void addEnodeB(cModule *eNodeB);
    void addBinder(Binder *binder);
    void setBaseUri(const std::string& baseUri);
    nlohmann::ordered_json toJsonCell(std::vector<MacCellId>& cellsID) const;
    nlohmann::ordered_json toJsonUe(std::vector<inet::Ipv4Address>& uesID) const;
    nlohmann::ordered_json toJson(std::vector<MacNodeId>& cellsID, std::vector<inet::Ipv4Address>& uesID) const;

  protected:
    // better to map <cellID, CellInfo>
    opp_component_ptr<Binder> binder_;
    TimeStamp timestamp_;
    std::map<MacCellId, CellInfo *> eNodeBs_;
    std::string baseUri_;

    UserInfo getUserInfoByNodeId(MacNodeId nodeId, MacCellId cellId) const;
    User getUserByNodeId(MacNodeId nodeId, MacCellId cellId) const;

    nlohmann::ordered_json getUserListPerCell(MacCellId macCellId, CellInfo *cellInfo) const;

};

} //namespace

#endif // _LOCATION_H_

