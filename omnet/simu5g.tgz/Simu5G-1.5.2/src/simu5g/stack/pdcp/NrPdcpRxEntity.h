//
//                  Simu5G
//
// Copyright (C) 2019-2021 Giovanni Nardini, Giovanni Stea, Antonio Virdis et al. (University of Pisa)
// Copyright (C) 2022-2026 Giovanni Nardini, Giovanni Stea et al. (University of Pisa)
//
// This file is part of a software released under the license included in file
// "license.pdf". Please read LICENSE and README files before using it.
// The above files and the present reference are part of the software itself,
// and cannot be removed from it.
//

#ifndef _NRPDCPRXENTITY_H_
#define _NRPDCPRXENTITY_H_

#include "simu5g/stack/pdcp/LtePdcpRxEntity.h"
#include "simu5g/stack/dcX2Forwarder/DcX2Forwarder.h"
#include "simu5g/common/timer/TTimer.h"

namespace simu5g {

/*
 * Descriptor of the entity status
 * Taken from 3GPP TS 38.323
 */
struct PdcpRxWindowDesc
{
  public:

    //! Size of the reception window
    unsigned int windowSize_ = 16;
    //! SN of the next SDU expected to be received (RX_NEXT)
    unsigned int rxNext_;
    //! SN of the first SDU not delivered to the upper layer (RX_DELIV)
    unsigned int rxDeliv_;
    //! SN of the SDU following the SDU that triggered t_reordering (RX_REORD)
    unsigned int rxReord_;

    void clear(unsigned int i = 0)
    {
        rxNext_ = i;
        rxDeliv_ = i;
        rxReord_ = i;
    }

    PdcpRxWindowDesc()
    {
        clear();
    }

};

enum PdcpRxTimerType
{
    REORDERING_T = 0
};

/**
 * @class NRPdcpEntity
 * @brief Entity for New Radio PDCP Layer
 *
 * This is the PDCP entity of LTE/NR Stack.
 *
 */
class NrPdcpRxEntity : public LtePdcpRxEntity
{
  protected:

    // true on a multi-leg bearer: reorder the SN stream merged from several legs
    bool reorderingEnabled_ = false;

    // if true, deliver packets to the upper layer without reordering
    // NOTE: reordering can apply for Split Bearers only
    bool outOfOrderDelivery_;

    // The SDU enqueue buffer.
    cArray sduBuffer_;

    // For each SDU a received status variable is kept
    std::vector<bool> received_;

    // State variables
    PdcpRxWindowDesc rxWindowDesc_;

    // Timer to manage the reordering of the PDUs
    TTimer t_reordering_ = TTimer(this);

    // Timeout for the above timer
    double timeout_;

    // handler for PDCP SDU
    void handlePdcpSdu(Packet *pdcpSdu, unsigned int sequenceNumber) override;

  public:


    void initialize(int stage) override;

    void handleMessage(cMessage *msg) override;

    bool isEmpty() const override { return sduBuffer_.size() == 0; }
};

} //namespace

#endif

