..\..\..\src\run_inet %*
